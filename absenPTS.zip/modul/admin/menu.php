<div class="container pt-3">
    <div class="row">
        <div class="col-md-4"><ul class="list-group">
              <li class="list-group-item active">MAIN MENU</li>
              <a href="siswa.php" class="list-group-item" style="color: #212529;">siswa</a>
              <a href="pengawas.php" class="list-group-item" style="color: #212529;">pengawas</a>
              <a href="panitia.php" class="list-group-item" style="color: #212529;">panitia</a>
              <a href="refresh.php" class="list-group-item" style="color: #212529;">bersihkan data</a>
              <a href="index.php" class="list-group-item" style="color: #212529;">Logout</a>
            </ul></div>
        